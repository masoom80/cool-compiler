public enum Type {
    CLASS,
    METHOD,
    VAR,
    ARRVAR

}
