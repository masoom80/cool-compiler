public class CodeGeneratorImpl implements CodeGenerator {
    @Override
    public void doSemantic(String sem) {

    }
}
